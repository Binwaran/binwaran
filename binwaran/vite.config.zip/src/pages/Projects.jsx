const Projects = () => {
    return (
      <div>
        <h1>Projects Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default Projects;
  