const AdminPanel = () => {
    return (
      <div>
        <h1>Admin Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default AdminPanel;