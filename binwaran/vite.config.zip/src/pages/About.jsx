const About = () => {
    return (
      <div>
        <h1>About Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default About;
  