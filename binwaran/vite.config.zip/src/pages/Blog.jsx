const Blog = () => {
    return (
      <div>
        <h1>Blog Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default Blog;
  