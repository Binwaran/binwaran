const Contact = () => {
    return (
      <div>
        <h1>Contact Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default Contact;
  