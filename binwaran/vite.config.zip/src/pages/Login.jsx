const Login = () => {
    return (
      <div>
        <h1>Login Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default Login;