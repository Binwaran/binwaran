const TechStack = () => {
    return (
      <div>
        <h1>TechStack Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default TechStack;
  